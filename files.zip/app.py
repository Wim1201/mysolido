from flask import Flask, render_template, request, redirect, url_for, flash
import requests

app = Flask(__name__)
app.secret_key = 'mysolido-dev-key-2026'

SOLID_POD_URL = 'http://localhost:3000/wim/'

@app.route('/')
def index():
    """Toon de inhoud van de pod"""
    try:
        response = requests.get(SOLID_POD_URL, headers={'Accept': 'text/turtle'})
        if response.status_code == 200:
            items = []
            for line in response.text.split('\n'):
                if 'ldp:contains' in line:
                    resource = line.split('<')[1].split('>')[0] if '<' in line else ''
                    if resource:
                        name = resource.rstrip('/').split('/')[-1]
                        is_folder = resource.endswith('/')
                        items.append({'name': name, 'url': resource, 'is_folder': is_folder})
            return render_template('index.html', items=items, pod_url=SOLID_POD_URL)
        else:
            flash(f'Kon pod niet laden: {response.status_code}', 'error')
            return render_template('index.html', items=[], pod_url=SOLID_POD_URL)
    except requests.ConnectionError:
        flash('CSS server niet bereikbaar. Draait hij op poort 3000?', 'error')
        return render_template('index.html', items=[], pod_url=SOLID_POD_URL)

@app.route('/upload', methods=['POST'])
def upload():
    """Upload een bestand naar de pod"""
    if 'file' not in request.files:
        flash('Geen bestand geselecteerd', 'error')
        return redirect(url_for('index'))
    
    file = request.files['file']
    if file.filename == '':
        flash('Geen bestand geselecteerd', 'error')
        return redirect(url_for('index'))
    
    upload_url = SOLID_POD_URL + file.filename
    content_type = file.content_type or 'application/octet-stream'
    
    response = requests.put(
        upload_url,
        data=file.read(),
        headers={'Content-Type': content_type}
    )
    
    if response.status_code in [200, 201]:
        flash(f'"{file.filename}" succesvol geupload!', 'success')
    else:
        flash(f'Upload mislukt: {response.status_code}', 'error')
    
    return redirect(url_for('index'))

@app.route('/delete', methods=['POST'])
def delete():
    """Verwijder een resource uit de pod"""
    resource_url = request.form.get('resource_url')
    if not resource_url:
        flash('Geen resource opgegeven', 'error')
        return redirect(url_for('index'))
    
    response = requests.delete(resource_url)
    
    if response.status_code in [200, 204]:
        name = resource_url.rstrip('/').split('/')[-1]
        flash(f'"{name}" verwijderd', 'success')
    else:
        flash(f'Verwijderen mislukt: {response.status_code}', 'error')
    
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(port=5000, debug=True)
